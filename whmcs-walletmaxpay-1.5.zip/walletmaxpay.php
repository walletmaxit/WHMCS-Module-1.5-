<?php
/* walletmaxpay WHMCS Gateway
 *
 * Copyright (c) 2023 walletmaxpay
 * Website: https://walletmaxpay.com
 * Developer: walletmaxpay LTD
 */

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

function walletmaxpay_MetaData(){
    return array(
        'DisplayName' => 'walletmaxpay Gateway',
        'APIVersion' => '1.5',
        'DisableLocalCredtCardInput' => true,
        'TokenisedStorage' => false,
    );
}




function walletmaxpay_link($params){
    $host_config = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
    $host_config =pathinfo($host_config, PATHINFO_FILENAME);  
        
    if(isset($_POST['pay'])){
        $response = walletmaxpay_payment_url($params);
        if ($response->status) {
            return '<form action="' . $response->payment_url . ' " method="GET">
            <input class="btn btn-primary" type="submit" value="' . $params['langpaynow'] . '" />
            </form>';
        }
    
        return $response->message;
    }
        
        
    if($host_config == "viewinvoice"){
        return '<form action="" method="POST">
        <input class="btn btn-primary" name="pay" type="submit" value="' . $params['langpaynow'] . '" />
        </form>';
    }else{
        $response = walletmaxpay_payment_url($params);
        if ($response->status) {
            return '<form action="' . $response->payment_url . ' " method="GET">
            <input class="btn btn-primary" type="submit" value="' . $params['langpaynow'] . '" />
            </form>';
        }
    
        return $response->message;
    }
}


function walletmaxpay_config(){
    return array(
        'FriendlyName' => array(
            'Type' => 'System',
            'Value' => 'walletmaxpay Payment Gateway',
        ),
        'apiKey' => array(
            'FriendlyName' => 'API Key',
            'Type' => 'text',
            'Size' => '150',
            'Default' => '',
            'Description' => 'Enter Your Api Key',
        ),
        'clientKey' => array(
            'FriendlyName' => 'Client Key',
            'Type' => 'text',
            'Size' => '150',
            'Default' => '',
            'Description' => 'Enter Your Client Key',
        ),
        'secretKey' => array(
            'FriendlyName' => 'Secret Key',
            'Type' => 'text',
            'Size' => '150',
            'Default' => '',
            'Description' => 'Enter Your Secret Key',
        ),
        'hostName' => array(
            'FriendlyName' => 'Host Name',
            'Type' => 'text',
            'Size' => '150',
            'Default' => '',
            'Description' => 'Enter Your Host Name',
        ),
        'currency_rate_edokan' => array(
            'FriendlyName' => 'Currency Rate',
            'Type' => 'text',
            'Size' => '150',
            'Default' => '85',
            'Description' => 'Enter Dollar Rate',
        )
    );
}

function walletmaxpay_payment_url($params){
    $cus_name = $params['clientdetails']['firstname'] . " " . $params['clientdetails']['lastname'];
    $cus_email = $params['clientdetails']['email'];

    $apikey = $params['apiKey'];
    $clientkey = $params['clientKey'];
    $secretkey = $params['secretKey'];

    $currency_rate_edokan = $params['currency_rate_edokan'];

    $invoiceId = $params['invoiceid'];

    if($params['currency'] == "USD"){
       $amount = $params['amount']*$currency_rate_edokan;
    }else{
        $amount = $params['amount'];
    }
    
    $systemUrl = $params['systemurl'];

    $success_url = $systemUrl . 'modules/gateways/callback/walletmaxpay.php?invoice='.$invoiceId;
    $cancel_url = $systemUrl . 'viewinvoice.php?id='.$invoiceId;
    $hostname = $params['hostName'];

    $curl = curl_init();
    curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://pay.walletmaxpay.com/checkout.php',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => array('api' => $apikey,'client' => $clientkey,'secret' => $secretkey,'amount' => $amount,'position' => $hostname,'success_url' => $success_url,'cancel_url' => $cancel_url,'cus_name' => $cus_name,'cus_email' => $cus_email),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    echo $response;
}
