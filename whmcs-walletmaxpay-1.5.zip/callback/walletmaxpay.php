<?php
    /* walletmaxpay WHMCS Gateway
     *
     * Copyright (c) 2022 walletmaxpay
     * Website: https://walletmaxpay.com
     * Developer: walletmaxpay LTD
     */
    
    require_once __DIR__ . '/../../../init.php';
    require_once __DIR__ . '/../../../includes/gatewayfunctions.php';
    require_once __DIR__ . '/../../../includes/invoicefunctions.php';
    
    use WHMCS\Config\Setting;


    $invoiceId = $_GET['invoice'];
    $transactionId = $_GET['transactionId'];
    $paymentAmount = $_GET['paymentAmount'];
    $paymentFee = $_GET['paymentFee'];
    $gatewayModuleName = "Bkash/Nagad/Rocket - walletmaxpay";


    $transaction_id_walletmaxpay = $transactionId;

    $curl = curl_init();
    curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://pay.walletmaxpay.com/verify.php',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => array('transaction_id' => $transaction_id_walletmaxpay),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    
    if($response == 1){
        addInvoicePayment(
            $invoiceId,
            $transactionId,
            $paymentAmount,
            $paymentFee,
            $gatewayModuleName
        );
        
        $systemUrl = Setting::getValue('SystemURL');
?>
        <script>
            location.href="<?php echo $systemUrl . '/viewinvoice.php?id=' . $invoiceId;?>";
        </script>
<?php
    }else{
        echo "Failed. Id Not Match";
    }
?>